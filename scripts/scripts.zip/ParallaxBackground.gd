extends ParallaxBackground

@export var scroll_speed := 400.0

func _ready():
	GameManager.parallax = self
