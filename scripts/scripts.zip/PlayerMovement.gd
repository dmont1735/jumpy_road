extends CharacterBody2D

@export var jump_speed := -825.0
@export var gravity_up := 800.0
@export var gravity_down := 1300.0

signal player_died()

var is_alive := true

func _ready():
	GameManager.player = self
	player_died.connect(GameManager._on_player_died)
	
func _physics_process(delta):
	if not is_alive:
		return

	# Apply different gravity depending on direction
	if velocity.y < 0:
		velocity.y += gravity_up * delta
	else:
		velocity.y += gravity_down * delta

	# Jump
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_speed

	move_and_slide()


func die():
	is_alive = false
	player_died.emit()

	# Reset game, play animation, etc…

