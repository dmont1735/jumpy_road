extends CanvasLayer

