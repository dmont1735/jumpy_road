extends ParallaxLayer

@export var speed_multiplier := 0.3
